//
//  ViewController.swift
//  Age
//
//  Created by Gudla,Mahesh on 1/23/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputOL1: UITextField!
    
    @IBOutlet weak var inputOL2: UITextField!
    
   
    @IBOutlet weak var outputOL: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBtnClicked(_ sender: Any) {
        // Read the entered Name and Course
        
        var ip1 = inputOL1.text
        var ip2 = inputOL2.text
        
        //Assign it to the display or output label
        // String interpolate with appropriate message
        
        outputOL.text = " Hi My Name is, \(ip1) \n and My Course is , \(ip2)"
    }
    
}

