//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Gudla,Mahesh on 3/7/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageOL: UIImageView!
    
    @IBOutlet weak var happyOL: UIButton!
    
    @IBOutlet weak var sadOL: UIButton!
    
    @IBOutlet weak var angryOL: UIButton!
    
    @IBOutlet weak var shakemeOL: UIButton!
    
    @IBOutlet weak var ShowMeOL: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        //keep all the components out of the view except show me button
        
        ImageOL.frame.origin.x = view.frame.width
        happyOL.frame.origin.x = view.frame.width
        sadOL.frame.origin.x = view.frame.width
        angryOL.frame.origin.x = view.frame.width
        shakemeOL.frame.origin.x = view.frame.width
    }
    
    @IBAction func happyBtnClicked(_ sender: Any) {
        updateandAnimate("happy")
    }
    
    @IBAction func sadBtnClicked(_ sender: Any) {
        updateandAnimate("sad")
    }
    
    @IBAction func angryBtnClicked(_ sender: Any) {
        updateandAnimate("angry")
    }
    
    @IBAction func shakemeBtnClicked(_ sender: Any) {
        //Increase the size of the image
        var width = ImageOL.frame.width
        width += 40
        var height = ImageOL.frame.height
        height += 40
        
        var x = ImageOL.frame.origin.x
        x -= 20
        var y = ImageOL.frame.origin.y
        y -= 20
        
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.ImageOL.frame = largeFrame
        })
    }
    
    @IBAction func showmeBtnClicked(_ sender: Any) {
        //move all the components from outsidenof the view to the centre of the view.
        UIView.animate(withDuration: 1, animations: {
            self.ImageOL.center.x = self.view.center.x
            self.happyOL.center.x = self.view.center.x
            self.sadOL.center.x = self.view.center.x
            self.angryOL.center.x = self.view.center.x
            self.shakemeOL.center.x = self.view.center.x
        })
        
        //Disable the show button
        ShowMeOL.isEnabled = false
        
    }
    
    func updateandAnimate(_ image:String){
        
        //Making the current image as opaque(alpha = 0)
        
        UIView.animate(withDuration: 1, animations: {
            self.ImageOL.alpha = 0
        })
        
        //assign the new image with an animation and make it transparent(alpha = 1)
    
        UIView.animate(withDuration: 1,delay: 0.5, animations: {
            self.ImageOL.alpha = 1
            self.ImageOL.image = UIImage(named: image)
        })
        
    }
}

