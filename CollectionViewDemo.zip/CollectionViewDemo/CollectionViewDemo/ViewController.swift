//
//  ViewController.swift
//  CollectionViewDemo
//
//  Created by Gudla,Mahesh on 4/2/24.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // create a cell
        let cell = movieCollectionOL.dequeueReusableCell(withReuseIdentifier: "reusableCell", for: indexPath) as! movieCollectionViewCell
        //populate a cell with an image
        cell.assignMovie(with:movies[indexPath.row])
        //return cell
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        // Assign movie details(Title,BoxOffice,Year Released,Rating).
        assignMovieDetails(index: indexPath)
    }
    func assignMovieDetails(index: IndexPath){
        titleOL.text = movies[index.row].title
        ratingOL.text = movies[index.row].movieRating
        boxOfficeOL.text = movies[index.row].boxOffice
        yearReleasedOL.text = movies[index.row].releasedYear
    }
    
    
    @IBOutlet weak var titleOL: UILabel!
    
    @IBOutlet weak var yearReleasedOL: UILabel!
    
    @IBOutlet weak var boxOfficeOL: UILabel!
    
    @IBOutlet weak var ratingOL: UILabel!
    
    @IBOutlet weak var movieCollectionOL: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        movieCollectionOL.dataSource = self
        movieCollectionOL.delegate = self
    }


}

