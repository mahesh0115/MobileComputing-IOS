//
//  movieCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Gudla,Mahesh on 4/2/24.
//

import UIKit

class movieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    func assignMovie(with movie:Movie){
        imageViewOL.image = movie.image
    }
    
}
