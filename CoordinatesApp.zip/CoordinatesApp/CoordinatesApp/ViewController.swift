//
//  ViewController.swift
//  CoordinatesApp
//
//  Created by Gudla,Mahesh on 2/29/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var ImageViewOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // Identify the min of x and y values of image view.
        let minX = ImageViewOL.frame.minX
        let minY = ImageViewOL.frame.minX
        
        print(minX,",", minY)
        
        // Identify the max of x and y values of image view.
        let maxX = ImageViewOL.frame.maxX
        let maxY = ImageViewOL.frame.maxY
        
        print(maxX,",",maxY)
       
        // Identify the mid values of x and y of the image view.
        let midX = ImageViewOL.frame.midX
        let midY = ImageViewOL.frame.midY
        
        print(midX,",",midY)
        
        // Move imgView to the upper left corner of the view.
        
        ImageViewOL.frame.origin.x = 0
        ImageViewOL.frame.origin.y = 0
        
        // Move imgView to the upper right corner of the view.
        
        ImageViewOL.frame.origin.x = 330
        ImageViewOL.frame.origin.y = 0
        
        // Move imgView to the bottom left corner of the view.
        ImageViewOL.frame.origin.x = 0
        ImageViewOL.frame.origin.y = 832
        
        // Move imgView to the bottom right corner of the view.
        
        ImageViewOL.frame.origin.x = 330
        ImageViewOL.frame.origin.y = 832
        
        // Move imgview to the centre of the view
        
        ImageViewOL.frame.origin.x = 215
        ImageViewOL.frame.origin.y = 466
        
        // Move centre of the imgview to the centre of the view
        
        ImageViewOL.frame.origin.x = 165
        ImageViewOL.frame.origin.y = 416
      
    }


}

