//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Gudla,Mahesh on 2/22/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var ImageViewOL: UIImageView!
    
    @IBOutlet weak var CourseNumOL: UILabel!
    @IBOutlet weak var CourseTitleOL: UILabel!
    @IBOutlet weak var SemesterOL: UILabel!
   
    @IBOutlet weak var PreviousOL: UIButton!
    
    
    @IBOutlet weak var NextOL: UIButton!
    
    let courses = [["img01","44555","Network Security","fall"],["img02","44666","ios","spring"],["img03","44556","Data Streaming","summer"]]
 
    var imgNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Previous button should be disabled
        
        PreviousOL.isEnabled = false;
        
        // Display the first Course details(index0)
        updateContents(imgNum)
        
    }

    @IBAction func PrevBtnClicked(_ sender: Any) {
        
        //next button should be enabled
        NextOL.isEnabled = true;
        
        //decrement the imagenumber
        imgNum = imgNum - 1;
        
        //update the contents
     updateContents(imgNum)
        
        //once you reach the beginning  of the array,the previous should be disabled
        if(imgNum == 0){
            PreviousOL.isEnabled = false;
        }
        
        
    }
    
    
    @IBAction func NextBtnClicked(_ sender: Any) {
        // previous button should be enabled
        PreviousOL.isEnabled = true;
        
        //Increment the image number
        imgNum = imgNum + 1;
        
        //updating the course details
        updateContents(imgNum)
        
        //once the user reach the end of the array,the next button should be disabled
        if(imgNum == courses.count-1){
            NextOL.isEnabled = false;
        }
    }// end of next button
    
    func updateContents(_ imageNumber : Int){
        ImageViewOL.image = UIImage(named: courses[imageNumber][0])
        CourseNumOL.text = courses[imageNumber][1]
        CourseTitleOL.text = courses[imageNumber][2]
        SemesterOL.text = courses[imageNumber][3]
    }

}

