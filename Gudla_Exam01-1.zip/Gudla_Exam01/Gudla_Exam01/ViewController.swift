//
//  ViewController.swift
//  Gudla_Exam01
//
//  Created by Mahesh Gudla on 2/15/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var patientIDTextField: UITextField!
    @IBOutlet weak var fbgTextField: UITextField!
    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    @IBAction func calculateButtonTapped(_ sender: UIButton) {
        guard let fbgText = fbgTextField.text, let fbg = Double(fbgText) else {
            return
        }
        
        let hba1c = 2.6 + (0.03 * fbg)
        var result = ""
        var healthTip = ""
        var imageName = ""
        let pid = patientIDTextField.text!
        let fbglevel = fbgTextField.text!
        switch hba1c {
        case ..<4.7:
            result = "Hypoglycemia"
            healthTip = "Eat food on time 🍎"
            imageName = "hypoglycemia"
        case 4.7..<5.6:
            result = "Normal"
            healthTip = "You are doing great 👍"
            imageName = "normal"
        case 5.6..<6.35:
            result = "Pre-Diabetes"
            healthTip = "You should work on your diet and maintain workout 🏋️"
            imageName = "pre-diabetes"
        default:
            result = "Diabetes"
            healthTip = "Consult doctor for medication 🩺"
            imageName = "diabetes"
        }
        
        resultLabel.text = " Patient ID : \(pid) \n FBG Level:\(fbglevel) (mg/dl)\n Hba1c(%): \(hba1c) (%) \n  Result: \(result) \n  Health Tip: \(healthTip) "
        imageView.image = UIImage(named: imageName)
    }
    
    @IBAction func resetButtonTapped(_ sender: UIButton) {
        patientIDTextField.text = ""
        fbgTextField.text = ""
        resultLabel.text = ""
        imageView.image = nil
    }
}


