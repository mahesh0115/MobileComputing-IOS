//
//  ViewController.swift
//  RestaurantApp
//
//  Created by Northwest on 2/26/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var itemOL: UILabel!
    
    
    @IBOutlet weak var sizeOL: UILabel!
    
    @IBOutlet weak var priceOL: UILabel!
    
    @IBOutlet weak var previousOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    //populate an array
    let items = [["chickenbiryani","Chicken Biryani","Full","12.99"],["muttonbiryani","Mutton Biryani","Full","13.99"],["fish-biryani","Fish Biryani","Full","14.99"],["prawnbiryani","Prawns Biryani","Full","15.99"] ]
    var imgNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previous button should be disabled
        previousOL.isEnabled = false;
        
        //dispaly the first course details(index 0)
        updateContents(imgNum)
    }

    @IBAction func previousBtnClicked(_ sender: Any) {
        
        //next button should be enabled
        nextOL.isEnabled = true;
        
       // decrement the image number
        imgNum = imgNum-1;
        
        //update the contents
        updateContents(imgNum)
        
        //once you reach the beginning of the array, the previous button should be disbaled
        if(imgNum == 0){
            previousOL.isEnabled = false;
        }
    }
    
    
    @IBAction func nextBtnClicked(_ sender: Any) {
        
        // previous button is enabled
        previousOL.isEnabled = true;
        
        //increment the image number
        imgNum = imgNum+1;
        
        //updating the course details
        updateContents(imgNum)
        
        //once the user reach the end of the array the next button should be enabled
        if(imgNum == items.count-1){
            nextOL.isEnabled = false;
        }
    }
    
    func updateContents(_ imageNumber:Int){
        
            imageOL.image = UIImage(named: items[imageNumber][0])
            itemOL.text = items[imageNumber][1]
            sizeOL.text = items[imageNumber][2]
            priceOL.text = items[imageNumber][3]
        
        }
}

