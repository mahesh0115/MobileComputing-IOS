//
//  ViewController.swift
//  Gudla_SearchApp
//
//  Created by Mahesh Gudla on 3/13/24.
//


import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextfield: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    @IBOutlet weak var prevBtn: UIButton!
    
    @IBOutlet weak var resetBtn: UIButton!
    
    @IBOutlet weak var nextBTN: UIButton!
    
    var imgarr = [["hibiscus","lavender","marigold","sunflower","tulips"],["dolphin","nemo","pufferFish","shark","whale"],["eagle","owl","parrot","hummingBird","phoenix"]]
    
    var flower_keywords = ["bloom","blossom","floret","flowret",]
    var fishes_keywords = ["coldfish","tallfish","bait","bob"]
    var birds_keywords = ["raptor","chick","birdie","fowl"]
      
    var topics = 0
    var imgNumber = 0
    
    var topics_array = [["Hibiscus is a genus of flowering plants in the mallow family, Malvaceae. The genus is quite large, comprising several hundred species that are native to warm temperate, subtropical and tropical regions throughout the world.","Lavandula (common name lavender) is a genus of 47 known species of flowering plants in the mint family, Lamiaceae. It is native to the Old World and is found in Cape Verde","Marigolds are native to subtropical America and have been grown in Mexico for over two millennia. The American marigold, sometimes called African, or Tagetes erecta, is known for its large flowers and tall plants","The common sunflower (Helianthus annuus) is a large annual forb of the genus Helianthus. It is commonly grown as a crop for its edible oily seeds.","Tulips (Tulipa) are a genus of spring-blooming perennial herbaceous bulbiferous geophytes (having bulbs as storage organs). The flowers are usually large, showy and brightly coloured, generally red, pink, yellow, or white (usually in warm colours)."],["A dolphin is an aquatic mammal within the infraorder Cetacea. Dolphin species belong to the families Delphinidae (the oceanic dolphins), Platanistidae (the Indian river dolphins), Iniidae (the New World river dolphins), Pontoporiidae (the brackish dolphins), and the extinct Lipotidae (baiji or Chinese river dolphin). There are 40 extant species named as dolphins.","The ocellaris clownfish (Amphiprion ocellaris), also known as the false percula clownfish or common clownfish, is a marine fish belonging to the family Pomacentridae, which includes clownfishes and damselfishes. Amphiprion ocellaris are found in different colors, depending on where they are located","Tetraodontidae is a family of primarily marine and estuarine fish of the order Tetraodontiformes. The family includes many familiar species variously called pufferfish, puffers, balloonfish, blowfish, blowers, blowies, bubblefish, globefish, swellfish, toadfish, toadies, toadle, honey toads, sugar toads, and sea squab.[1] They are morphologically similar to the closely related porcupinefish, which have large external spines (unlike the thinner, hidden spines of the Tetraodontidae, which are only visible when the fish have puffed up)","Sharks are a group of elasmobranch fish characterized by a cartilaginous skeleton, five to seven gill slits on the sides of the head, and pectoral fins that are not fused to the head. Modern sharks are classified within the clade Selachimorpha (or Selachii) and are the sister group to the Batoidea (rays and kin).","Whales are a widely distributed and diverse group of fully aquatic placental marine mammals. As an informal and colloquial grouping, they correspond to large members of the infraorder Cetacea, i.e. all cetaceans apart from dolphins and porpoises. Dolphins and porpoises may be considered whales from a formal, cladistic perspective."],["Eagle is the common name for many large birds of prey of the family Accipitridae. Eagles belong to several groups of genera, some of which are closely related. Most of the 68 species of eagles are from Eurasia and Africa.","Owls are birds from the order Strigiformes which includes over 200 species of mostly solitary and nocturnal birds of prey typified by an upright stance, a large, broad head, binocular vision, binaural hearing, sharp talons, and feathers adapted for silent flight. Exceptions include the diurnal northern hawk-owl and the gregarious burrowing owl.","Parrots, also known as psittacines are birds of the roughly 398 species in 92 genera comprising the order Psittaciformes , found mostly in tropical and subtropical regions.","Hummingbirds are birds native to the Americas and comprise the biological family Trochilidae. With about 366 species and 113 genera,they occur from Alaska to Tierra del Fuego, but most species are found in Central and South America.","The phoenix is an immortal bird associated with Greek mythology (with analogs in many cultures) that cyclically regenerates or is otherwise born again."]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        topics = 0
        
        resultImage.image = UIImage(named: "welcome")
        
        topicInfoText.isHidden = true
        topicInfoText.text = ""
                
        searchBtn.isEnabled = false
                
        prevBtn.isHidden = true
                
        nextBTN.isHidden = true
                
        resetBtn.isHidden = true
    }


    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        
                imgNumber = imgNumber - 1
                nextBTN.isEnabled = true
                switch topics {
                case 1 :
                    resultImage.image = UIImage (named: imgarr [0][imgNumber])
                    topicInfoText.text = topics_array[0][imgNumber]
                case 2 :
                    resultImage.image = UIImage (named: imgarr [1][imgNumber])
                    topicInfoText.text = topics_array[1][imgNumber]
                case 3 :
                    resultImage.image = UIImage (named: imgarr [2][imgNumber])
                    topicInfoText.text = topics_array[2][imgNumber]
                default :
                    print("enter into default")
                    
                }
                if (imgNumber == 0) {
                    prevBtn.isEnabled = false
                } else {
                    prevBtn.isEnabled = true
                }
                
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
        
        imgNumber = 0
        topicInfoText.isHidden = false
                if(flower_keywords.contains (searchTextfield.text!)) {
                    topics = 1
                    nextBTN.isEnabled = true
                    prevBtn.isEnabled = false
                    
                    prevBtn.isHidden = false
                    nextBTN.isHidden = false
                    resetBtn.isHidden = false
                    resultImage.image = UIImage (named: imgarr[0][0])
                    topicInfoText.text = topics_array[0][0]
                } else if (fishes_keywords.contains(searchTextfield.text!)) {
                    topics = 2
                    nextBTN.isEnabled = true
                    prevBtn.isEnabled = false
                    
                    prevBtn.isHidden = false
                    nextBTN.isHidden = false
                    
                    resetBtn.isHidden = false
                    
                    
                    resultImage.image = UIImage (named: imgarr [1][0])
                    topicInfoText.text = topics_array[1][0]
                    
                } else if (birds_keywords.contains (searchTextfield.text!)){
                    topics = 3
                    nextBTN.isEnabled = true
                    prevBtn.isEnabled = false
                    
                    prevBtn.isHidden = false
                    nextBTN.isHidden = false
                    resetBtn.isHidden = false
                    resultImage.image = UIImage (named: imgarr [2][0])
                    topicInfoText.text = topics_array[2][0]
                    
                    
                } else {
                    resultImage.image = UIImage (named: "robo")
                    prevBtn.isHidden = true
                    nextBTN.isHidden = true
                    resetBtn.isHidden = true
                }
                
    }
    
    
    @IBAction func showNextImagesBtn(_ sender: UIButton) {
        
        imgNumber = imgNumber + 1
                prevBtn.isEnabled = true
                nextBTN.isEnabled = true
                switch topics {
                case 1:
                    resultImage.image = UIImage (named: imgarr [0][imgNumber])
                    topicInfoText.text = topics_array[0][imgNumber]
                case 2:
                    resultImage.image = UIImage (named: imgarr [1][imgNumber])
                    topicInfoText.text = topics_array[1][imgNumber]
                case 3:
                    resultImage.image = UIImage (named: imgarr[2][imgNumber])
                    topicInfoText.text = topics_array[2][imgNumber]
                default:
                    print ("")
                }
                if (imgNumber == imgarr[0].count - 1) {
                    nextBTN.isEnabled = false
                } else {
                    nextBTN.isEnabled = true
                }
            
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        
        searchTextfield.text = ""
                      imgNumber = 0
                      searchBtn.isEnabled = false
                      resultImage.image = UIImage(named: "welcome")
                      
                      topicInfoText.text = ""
               prevBtn.isHidden = true
               nextBTN.isHidden = true
               resetBtn.isHidden = true
                      topics = 0
        topicInfoText.isHidden = true
                      
                  }
    
    
    @IBAction func editText(_ sender: UITextField) {
        
        if searchTextfield.text!.isEmpty{
                           searchBtn.isEnabled = false
                       } else {
                           searchBtn.isEnabled = true
                       }
    }
    
    
    
}

