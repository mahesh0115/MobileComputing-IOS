//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Gudla,Mahesh on 3/28/24.
//

import UIKit

class Product{
    var productname: String?
    var productCategory: String?
    
    init(productname: String? = nil, productCategory: String? = nil) {
        self.productname = productname
        self.productCategory = productCategory
    }
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Retrun number of products
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a Cell
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        //populate a Cell
        cell.textLabel?.text = products[indexPath.row].productname
        //return a cell
        return cell
    }
    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var products = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewOL.delegate = self
        tableViewOL.dataSource = self
    
        let p1 = Product(productname: "iphone",productCategory: "Mobile phones")
        products.append(p1)
        let p2 = Product(productname: "Macbook",productCategory: "Laptops")
        products.append(p2)
        let p3 = Product(productname: "iwatch",productCategory: "Watchs")
        products.append(p3)
        let p4 = Product(productname: "VisionPro",productCategory: "Virtual Reality")
        products.append(p4)
        let p5 = Product(productname: "ipad",productCategory: "Tablets")
        products.append(p5)
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(segue.identifier == "productDescriptionSegue"){
            let destination = segue.destination as! DescriptionViewController
            destination.product = products[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
    }

}

