//
//  ViewController.swift
//  Temperature App
//
//  Created by Gudla,Mahesh on 1/25/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func checkBtnClicked(_ sender: Any) {
        
        //Read the entered text and assign to a var.
        
        //Check for the condition and assign the value
        var temp = Int(inputOL.text!) ?? 0
        if(temp >= 60){
            outputOL.text = "It's Hot Outside"
        }
        else{
            outputOL.text = "It's Cold outside"
        }
        
    }
    
}
