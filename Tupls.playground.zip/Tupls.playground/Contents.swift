import UIKit

var greeting = "Hello, playground"
//
//  Tuples.swift
//
//
//  Created by Gudla,Mahesh on 1/18/24.
//

var httpError = (errorcode : 404, errorMessage: "page not found")
print(httpError)
print(httpError.errorcode, terminator : ": ")
print(httpError.errorMessage)

var name = ("jhon","smith")
var fName = name.0
var lName = name.1
print(fName, terminator : ",")
print(lName)

