//
//  ViewController.swift
//  VowelTester
//
//  Created by Gudla,Mahesh on 1/25/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func CheckBtnClicked(_ sender: Any) {
        
        //Read the entered text and assign it to a variable
        
        var input = inputOL.text!
        
        
        //check for vowels using if statement.
        
        if(input.contains("a") ||
           input.contains("e") ||
           input.contains("i") ||
           input.contains("o") ||
           input.contains("u")){
            print("\(input) contains vowels")
            //Assign the output label
            outputOL.text = "\(input) contains vowels"
        }
        else{
            //print the message.
            print("\(input) does not contains vowels")
            outputOL.text = "\(input) does not contains vowels"
        }
        
    }
    
}
