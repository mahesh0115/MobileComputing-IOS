//
//  ViewController.swift
//  WeatherAppMultipleViewController
//
//  Created by Gudla,Mahesh on 3/21/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var temperatureOL: UITextField!
    
    var result = ""
    var image = ""
    var temperature:Double = 0.0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func checkWeatherBtn(_ sender: Any) {
        
        // read the temperature and assign it to a variable
         temperature = Double(temperatureOL.text!)!
        
        //Check weather it is hot or cold
        if(temperature<60){
            result = "It is Cold"
            image = "Cold"
        }
        else {
            result = "It is Hot"
            image = "Hot"
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Know the identifier
        let transition = segue.identifier
        // set the destination
        if(transition == "WeatherSegue"){
            let destination = segue.destination as! ResultViewController
        //Assign the values to the destination variables.
            destination.image = image
            destination.result = result
            destination.temperature = temperature
            
            
        }
    }
    
    
}

