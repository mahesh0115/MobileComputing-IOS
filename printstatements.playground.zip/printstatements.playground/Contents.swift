import UIKit

var greeting = "Hello, playground"
print("Hello All 👋🏻")
print("Hii",10,12.25)

var programminglanguage = "swift"
print("My favourite programming language is \(programminglanguage)")

var age = 23
print("you are \(age) years old and in another \(age) years, you will be \(age * 2)")

print("""
Hello World!
""")

print("Hello All \rWelcome to the swift Programming")

let welcomemessage : String = "Hello!"
print("welcome message,All")

print("welcome to swift programming")
print("Fall 2021")
print("**********")
print("Welcome to swift Programming" , terminator: "-")
print("Fall 2021")
print("The list of numbers are")
print("1,2,3,4,5,6")
print("The new pattern is")
print(1,2,3,4,5,6, separator : "-")

var mobilebrand = "Apple"
mobilebrand = "samsung"
print(mobilebrand)


